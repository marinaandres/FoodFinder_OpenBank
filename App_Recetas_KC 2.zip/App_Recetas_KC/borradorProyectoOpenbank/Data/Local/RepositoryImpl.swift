//
//  RepositoryImpl.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 4/8/23.
//

import Foundation

final class RepositoryImpl: RepositoryProtocol {
    
    // MARK: - Initials variables
    
    private let remoteDataSource: RemoteDataSourceProtocol
    
    // MARK: - Init
    
    init(remoteDataSource: RemoteDataSourceProtocol) {
        self.remoteDataSource = remoteDataSource
    }
    
    // MARK: - Repository protocol functions
    
    func getRecipes(query: String, completion: @escaping (Result?, NetworkError?) -> ()) {
        remoteDataSource.getRecipes(query: query) { (result: Result?, error: NetworkError?) in
            completion(result, error)
        }
    }
}
