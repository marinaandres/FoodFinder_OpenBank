//
//  ListViewModelTest.swift
//  borradorProyectoOpenbankTests
//
//

import XCTest
@testable import borradorProyectoOpenbank

final class ListViewModelTest: XCTestCase {
    
    var sut: ListViewModel?
    var query: String?
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        let mockRepository = MockRepository()
        let mockListViewController = MockListViewController()
        let collectionViewMock = MockListViewController()
        sut = ListViewModel(repository: mockRepository, listView: mockListViewController)
    }
    
    func testListViewModel_whenCurrentQueryIsEmpty_expectAllRecipes() {
        let mockResultElement1 = ResultElement(id: 1, title: "Recipe 1", image: "image1.jpg", imageType: .jpg, readyInMinutes: 45, servings: 4)
        let mockResultElement2 = ResultElement(id: 2, title: "Recipe 2", image: "image2.jpg", imageType: .jpg, readyInMinutes: 30, servings: 6)
        let mockResult = Result(results: [mockResultElement1, mockResultElement2], offset: 0, number: 2, totalResults: 2)
        query = ""
        sut?.result = mockResult
        sut?.currentQuery = query!
        sut?.getRecipe(withQuery: query!, completion: {
            //x
        })
        XCTAssertEqual(sut?.filteredRecipes.count, 2, "Expected 2 recipes when currentQuery is empty")
    }
    
    func testListViewModel_whenCurrentQueryIsNotEmpty_expectFilteredRecipes() {
        let mockResultElement1 = ResultElement(id: 1, title: "Recipe 1", image: "image1.jpg", imageType: .jpg, readyInMinutes: 45, servings: 4)
        let mockResultElement2 = ResultElement(id: 2, title: "Recipe 2", image: "image2.jpg", imageType: .jpg, readyInMinutes: 30, servings: 6)
        let mockResult = Result(results: [mockResultElement1, mockResultElement2], offset: 0, number: 1, totalResults: 1)
        query = "Recipe 1"
        sut?.result = mockResult
        sut?.currentQuery = query!
        
        sut?.getRecipe(withQuery: query!, completion: {
        })
        XCTAssertEqual(sut?.filteredRecipes.count, 1, "Expected 1 recipe matching the currentQuery")
    }

    func testListViewModel_getRecipeWithQuery_successfulFetch() {
        let expectation = XCTestExpectation(description: "Fetch recipes successfully")
        let mockRepository = MockRepository(getRecipesSuccess: true)
        let mockListViewController = MockListViewController() // Use the mock here
        
        query = sut?.currentQuery
        sut = ListViewModel(repository: mockRepository, listView: mockListViewController) // Use the mock here
        
        sut?.getRecipe(withQuery: query ?? "") {
            expectation.fulfill()
            XCTAssertNotNil(self.sut?.result, "Expected result to be fetched successfully")
            XCTAssertEqual(self.sut?.result?.results.count, 2, "Expected 2 recipes in the result")
        }
        wait(for: [expectation], timeout: 1.0)
    }
}
