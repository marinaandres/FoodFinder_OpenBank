//
//  MockRemoteDataSource.swift
//  borradorProyectoOpenbankTests
//
//

import Foundation
@testable import borradorProyectoOpenbank

class MockRemoteDataSource: RemoteDataSourceProtocol {
    
    let recipeSuccess: Bool
    
    init(recipeSuccess: Bool = false) {
        self.recipeSuccess = recipeSuccess
    }
   
    func getRecipes(query: String, completion: @escaping (Result?, NetworkError?) -> ()) {
        switch recipeSuccess {
        case true:
            let stubResult = getStubResult()
            completion(stubResult, nil)
        case false:
            completion(nil, .other)
        }
    }
    
    private func getStubResult() -> Result {
        let mockResultElement = ResultElement(id: 1, title: "Mock Recipe", image: "Mock_image.jpg", imageType: .jpg, readyInMinutes: 45, servings: 4)
        return Result(results: [mockResultElement], offset: 0, number: 1, totalResults: 1)
    }
}

