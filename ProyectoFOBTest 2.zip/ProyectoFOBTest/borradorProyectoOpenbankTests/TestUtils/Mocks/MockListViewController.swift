//
//  MockListViewController.swift
//  borradorProyectoOpenbankTests
//
//  Created by Andrés Aragón Marina on 9/8/23.
//
import XCTest
import UIKit
@testable import borradorProyectoOpenbank

class MockListViewController: ListViewController {
   
    var dataLoaded = false
    var searchBarText: String?
    var didSelectItemAtIndexPath: IndexPath?
    var collectionViewMock:UICollectionView?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        createCollectionView()
        setSearchBar()
    }

    func createCollectionView() -> UICollectionView? {
      return collectionViewMock
    }
    
    
    func setSearchBar() {
        
    }
    

    override func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchBarText = searchText
        
        return
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionViewMock = collectionView
        return UICollectionViewCell()
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 2
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        didSelectItemAtIndexPath = indexPath
    }
    
    
    
}




/*import UIKit
@testable import borradorProyectoOpenbank

class MockListViewController: ListViewController {
    
    
    var currentQuery: String = ""
    var mockCollectionView: UICollectionView =
    
    init(currentQuery: String, mockCollectionView: UICollectionView) {
        self.currentQuery = currentQuery
        self.mockCollectionView = mockCollectionView
        setCollectionView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setCollectionView() {
        mockCollectionView.dataSource =
        mockCollectionView.delegate =
        mockCollectionView.register(UINib(nibName: "MyCustomCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "myCell")
    }
}
extension MockListViewController {
    override func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        listViewModel?.getRecipe(withQuery: currentQuery, completion: {
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
        )}
}
extension MockListViewController {
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listViewModel?.filteredRecipes.count ?? 0
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        //creamos celda
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as? MyCustomCollectionViewCell
        
        //Comprobamos que el resultado sea correcto
        guard let result = listViewModel?.result else {
            return cell!
           }
        
        //Comprobamos que el indexpath.row sea positivo
        guard indexPath.row < result.results.count else {
            return cell!
           }
        
        //Asignamos el texto del resultado al titulo de la receta
        let recipe = result.results[indexPath.row]
        cell!.myCellLabel.text = recipe.title
        
        //Asignamos la imagen del resultado a la imagen de la receta
        let imageUrlString = recipe.image
        
        if let imageUrl = URL(string: imageUrlString) {
            cell!.myCellImage.setImage(url: imageUrl)
        } else {
            cell!.myCellImage.image = UIImage(named: "placeholderImage")
        }
        
        return cell!
    }
}
 */
