//
//  UIImageViewExtension.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 7/8/23.
//
import UIKit

extension UIImageView {
    
    
    func setImage(url: URL?) {
        guard let unwrappedURL = url else { return }
        downloadWithUrlSession(url: unwrappedURL) { [weak self] downloadedImage in
            // Asignamos a la imagen del contenedor en el que estamos (UIImage view) la imagen descargada
            DispatchQueue.main.async {
                self?.image = downloadedImage
            }
        }
    }
    
    private func downloadWithUrlSession(url: URL, completion: @escaping (UIImage?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data,
                  let image = UIImage(data: data) else {
                print("No se ha descargado la imagen")
                completion(nil)
                return
            }
        print("Se ha descargado la imagen")
                completion(image)
        }.resume()

    }
    
}
