//
//  MyCustomCollectionViewCell.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 7/8/23.
//

import UIKit

class MyCustomCollectionViewCell: UICollectionViewCell {
    

    @IBOutlet weak var myCellImage: UIImageView!
    @IBOutlet weak var myCellLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setImageLayout()
    }

    func setImageLayout() {
        myCellImage.image = UIImage(named: "fondo2")
        myCellImage.layer.cornerRadius = myCellImage.frame.height / 8
        myCellImage.clipsToBounds = true
        myCellLabel.font = UIFont.boldSystemFont(ofSize: 18)
    }

}



