//
//  DetailViewModelTest.swift
//  borradorProyectoOpenbankTests
//
//  Created by Marina Andrés Aragón on 9/8/23.
//

import XCTest
@testable import borradorProyectoOpenbank

class DetailViewModelTests: XCTestCase {
    
    func testRecipeTitle_whenSelectedRecipeIsSet_expectCorrectTitle() {
            // Create a sample ResultElement
            let sampleRecipe = ResultElement(
                id: 1,
                title: "Sample Recipe",
                image: "https://example.com/image.jpg",
                imageType: .jpg,
                readyInMinutes: 30,  // Sample value for readyInMinutes
                servings: 4          // Sample value for servings
            )
            
           
            let viewModel = DetailViewModel(selectedRecipe: sampleRecipe)
            
            
            XCTAssertEqual(viewModel.recipeTitle, "Sample Recipe")
        }
        
        func testRecipeImageURL_whenSelectedRecipeIsSet_expectCorrectImageURL() {
            // Create a sample ResultElement
            let sampleRecipe = ResultElement(
                id: 1,
                title: "Sample Recipe",
                image: "https://example.com/image.jpg",
                imageType: .jpg,
                readyInMinutes: 30,
                servings: 4
            )
            
            let viewModel = DetailViewModel(selectedRecipe: sampleRecipe)
            
            
            XCTAssertEqual(viewModel.recipeImageURL, URL(string: "https://example.com/image.jpg"))
        }

        func testSetImageBounds_whenImageViewIsProvided_expectCornerRadiusSet() {
            // Create a sample ResultElement
            let sampleRecipe = ResultElement(
                id: 1,
                title: "Sample Recipe",
                image: "https://example.com/image.jpg",
                imageType: .jpg,
                readyInMinutes: 30,
                servings: 4
            )
            
           
            let viewModel = DetailViewModel(selectedRecipe: sampleRecipe)
        
            let imageView = UIImageView()
           
            viewModel.setImageBounds(for: imageView)
        
            XCTAssertEqual(imageView.layer.cornerRadius, imageView.frame.height / 8)
        }
    }
