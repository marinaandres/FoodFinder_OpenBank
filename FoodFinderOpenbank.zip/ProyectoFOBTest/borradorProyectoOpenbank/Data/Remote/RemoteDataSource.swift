//
//  RemoteDataSource.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 4/8/23.
//

import Foundation

enum NetworkError: Error, Equatable {
    case malformedURL
    case noData
    case noUser
    case errorCode(Int?)
    case tokenFormat
    case decoding
    case other
}

final class RemoteDataSourceImpl: RemoteDataSourceProtocol {

    // MARK: - Properties
    private let session: URLSession
    private let urlBase: String = "https://api.spoonacular.com"
    //private let apiKey = "03ad9872f9eb48dca2c4b8ceb1857f00"
    private let apiKey = "cf613fb1d98b428ebcae7a754bd46988"

    init(session: URLSession = URLSession.shared) {
        self.session = session
    }

    func getRecipes(query: String, completion: @escaping (Result?, NetworkError?) -> ()) {
        guard var urlComponents = URLComponents(string: "\(urlBase)/recipes/complexSearch") else {
            completion(nil, .malformedURL)
            return
        }
        
        let apiKeyQueryItem = URLQueryItem(name: "apiKey", value: apiKey)
        let queryQueryItem = URLQueryItem(name: "query", value: query)
        let numberQueryItem = URLQueryItem(name: "number", value: "50")
        let addRecipeInformationItem = URLQueryItem(name: "addRecipeInformation", value: "true")
    
        urlComponents.queryItems = [apiKeyQueryItem, queryQueryItem, numberQueryItem, addRecipeInformationItem]
        
        guard let url = urlComponents.url else {
            completion(nil, .malformedURL)
            return
        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        
        let task = session.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(nil, .other)
                return
            }
            
            guard let data = data else {
                completion(nil, .noData)
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else {
                let statusCode = (response as? HTTPURLResponse)?.statusCode
                completion(nil, .errorCode(statusCode))
                return
            }
            
            do {
                let result = try JSONDecoder().decode(Result.self, from: data)
                completion(result, nil)
            } catch {
                print("Error decoding: \(error.localizedDescription)")
                completion(nil, .decoding)
            }
        }
        
        task.resume()
    }
}
