//
//  Recipe.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 4/8/23.

import Foundation
// MARK: - Result
struct Result: Codable {
    let results: [ResultElement]
    let offset, number, totalResults: Int
}

// MARK: - ResultElement
struct ResultElement: Codable {
    let id: Int
    let title: String
    let image: String
    let imageType: ImageType
    let readyInMinutes: Int?
    let servings: Int?
}

enum ImageType: String, Codable {
    case jpg = "jpg"
}
