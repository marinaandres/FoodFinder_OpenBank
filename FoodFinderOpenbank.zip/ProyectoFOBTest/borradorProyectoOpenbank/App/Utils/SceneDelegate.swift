//
//  SceneDelegate.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 2/8/23.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    
    var window: UIWindow?
    
    
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        
        // Verificar que la escena sea una UIWindowScene
               guard let windowScene = scene as? UIWindowScene else { return }

               // Crear la ventana y establecer la escena
            let window = UIWindow(windowScene: windowScene)
            let viewController = InitialViewController(nibName: "InitialView", bundle: nil)
            let navigationController = UINavigationController(rootViewController: viewController)
            //navigationController.navigationBar.isHidden = false
            navigationController.navigationBar.tintColor = .black
        

                //Modificar el botón de retroceso global del UINavigationController
            let backButtonImage = UIImage(named: "")
            navigationController.navigationBar.backIndicatorImage = backButtonImage
            navigationController.navigationBar.backIndicatorTransitionMaskImage = backButtonImage
        
                // Configurar el estilo del botón de retroceso
            //navigationController.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
            window.rootViewController = navigationController
            self.window = window
            window.makeKeyAndVisible()
        
    }
    
    func sceneDidDisconnect(_ scene: UIScene) {
        
    }
    
    func sceneDidBecomeActive(_ scene: UIScene) {
        
    }
    
    func sceneWillResignActive(_ scene: UIScene) {
        
    }
    
    func sceneWillEnterForeground(_ scene: UIScene) {
        
    }
    
    func sceneDidEnterBackground(_ scene: UIScene) {
        
    }
    
}


