//
//  DetailViewModel.swift
//  borradorProyectoOpenbank
//
//  Created by Andrés Aragón Marina on 9/8/23.
//


import UIKit

class DetailViewModel {
    var selectedRecipe: ResultElement?

    init(selectedRecipe: ResultElement) {
        self.selectedRecipe = selectedRecipe
    }
    
    var recipeTitle: String? {
        return selectedRecipe?.title
    }
    
    var recipeImageURL: URL? {
        if let imageUrlString = selectedRecipe?.image {
            return URL(string: imageUrlString)
        }
        return nil
    }
    
    var recipeImageUI: UIImage? {
        return nil
    }
    
    var recipeServings: String? {
        if let servings = selectedRecipe?.servings {
            return String(servings)
        }
        return nil
    }
    
    var recipeTime: String? {
        if let time = selectedRecipe?.readyInMinutes {
            return String(time)
        }
        return nil
    }
    
    func setImageBounds(for imageView: UIImageView) {
        imageView.clipsToBounds = true
        
    }
}

