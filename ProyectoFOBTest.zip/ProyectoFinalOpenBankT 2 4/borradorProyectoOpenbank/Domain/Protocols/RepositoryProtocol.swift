//
//  RepositoryProtocol.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 4/8/23.
//

import Foundation

protocol RepositoryProtocol {
    func getRecipes(query: String, completion: @escaping (Result?, NetworkError?) -> ())
}
