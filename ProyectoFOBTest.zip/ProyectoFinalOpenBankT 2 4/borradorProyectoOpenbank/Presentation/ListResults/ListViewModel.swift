//
//  ListViewModel.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 4/8/23.
//

import Foundation

final class ListViewModel {
    
    // MARK: Properties
    private let repository: RepositoryProtocol
    private weak var listView: ListViewController?
    var currentQuery: String = ""
    var result: Result?
    
    var filteredRecipes: [ResultElement] {
            if let result = result {
                if currentQuery.isEmpty {
                    return result.results
                } else {
                    return result.results.filter { $0.title.lowercased().contains(currentQuery.lowercased()) }
                }
            }
            return []
        }
        
        
        // MARK: - Init
        init(repository: RepositoryProtocol, listView: ListViewController) {
                self.repository = repository
                self.listView = listView
                getRecipe(withQuery: "") {
                    DispatchQueue.main.async {
                        listView.collectionView.reloadData()
                        print("Se ha ejecutado getRecipes")
                    }
                }
            }
    // MARK: - Methods
        func getRecipe(withQuery query: String, completion: @escaping () -> ()) {
            currentQuery = query
            repository.getRecipes(query: query) { result, error in
                guard error == nil else {
                    print("Error loading recipes: \(String(describing: error))")
                    return
                }
                self.result = result
                completion()
                print("Se han obtenido las recetas")
            }
        }
    }
    
