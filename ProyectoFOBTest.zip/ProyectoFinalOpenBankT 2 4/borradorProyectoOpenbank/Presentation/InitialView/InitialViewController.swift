//
//  InitialViewController.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 2/8/23.
//

import UIKit

class InitialViewController: UIViewController {
    
    @IBOutlet weak var initialImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       setImageDesign()

    }
    
    func setImageDesign() {
        initialImage.layer.cornerRadius = initialImage.frame.height / 10
        initialImage.clipsToBounds = true
    }
    
    @IBAction func navigateToListVC(_ sender: Any) {
        let listViewController = ListViewController()
        self.navigationController?.pushViewController(listViewController, animated: false)
    }
}
