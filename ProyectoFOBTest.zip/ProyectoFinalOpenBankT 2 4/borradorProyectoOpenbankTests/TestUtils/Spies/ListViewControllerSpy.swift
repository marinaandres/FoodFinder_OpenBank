//
//  ListViewControllerSpy.swift
//  borradorProyectoOpenbankTests
//
//  Created by Adrian Quiroz on 8/8/23.
//
import XCTest
@testable import borradorProyectoOpenbank

final class ListViewControllerSpy: ListViewController {
    
        var didCallUpdateView = false
        var didCallCollectionViewReloadData = false
        var searchTextDidChange: String?
    
        
        override func viewDidLoad() {
            super.viewDidLoad()
            didCallUpdateView = true
        }
        
        override func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            searchTextDidChange = searchText
        }
        
        override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            didCallCollectionViewReloadData = true
            return super.collectionView(collectionView, cellForItemAt: indexPath)
        }
        
        // Métodos públicos para verificar interacciones
        func verifyUpdateViewCalled() -> Bool {
            return didCallUpdateView
        }
        
        func verifyCollectionViewReloadDataCalled() -> Bool {
            return didCallCollectionViewReloadData
        }
    }

