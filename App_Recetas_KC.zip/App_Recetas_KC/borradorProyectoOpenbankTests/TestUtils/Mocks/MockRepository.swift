//
//  MockRepository.swift
//  borradorProyectoOpenbankTests
//
//

import Foundation
@testable import borradorProyectoOpenbank

final class MockRepository: RepositoryProtocol {
    
    let getRecipesSuccess: Bool
    
    init(getRecipesSuccess: Bool = false) {
        self.getRecipesSuccess = getRecipesSuccess
    }
    
    func getRecipes(query: String, completion: @escaping (borradorProyectoOpenbank.Result?, borradorProyectoOpenbank.NetworkError?) -> ()) {
        if getRecipesSuccess {
            let mockResultElement1 = ResultElement(id: 1, title: "Recipe 1", image: "image1.jpg", imageType: .jpg, readyInMinutes: 45, servings: 4)
            let mockResultElement2 = ResultElement(id: 2, title: "Recipe 2", image: "image2.jpg", imageType: .jpg, readyInMinutes: 30, servings: 6)
            let mockResult = Result(results: [mockResultElement1, mockResultElement2], offset: 0, number: 2, totalResults: 2)
            completion(mockResult, nil)
        } else {
            completion(nil, .other) // You can set the appropriate error case here
        }
    }
}
