//
//  RepositoryTests.swift
//  borradorProyectoOpenbankTests
//
//

import XCTest
@testable import borradorProyectoOpenbank

final class RepositoryTests: XCTestCase {

    // MARK: - Sut
    var sut: RepositoryProtocol?

    override func setUpWithError() throws {
        try super.setUpWithError()
        let remoteDataSource = MockRemoteDataSource()
        sut = RepositoryImpl(remoteDataSource: remoteDataSource)
    }

    override func tearDownWithError() throws {
        sut = nil
        try super.tearDownWithError()
    }

    
    func testRepository_whenGetRecipesWithMockRemoteGetRecipesFail_expectError() {
        
        // GIVEN
        let expectation = XCTestExpectation(description: "ERROR")

        // WHEN
        sut?.getRecipes(query: "", completion: { result, error in
            XCTAssertNotNil(error, "Error must be thrown when get heroes is unsuccessful")
            expectation.fulfill()
        })
        
        wait(for: [expectation], timeout: 1.0)
    }

    func testRepository_whenGetRecipesWithMockRemoteGetRecipesSuccessful_expectRecipes() {
        
        
        let expectation = XCTestExpectation(description: "HEROES")

        let mockRemoteDataSource = MockRemoteDataSource(recipeSuccess: true)
        sut = RepositoryImpl(remoteDataSource: mockRemoteDataSource)
        // WHEN
        sut?.getRecipes(query: "", completion: { result, error in
            XCTAssertNotNil(result, "Error must be thrown when get heroes is unsuccessful")
       
            expectation.fulfill()
        })
        
        wait(for: [expectation], timeout: 1.0)
    }

}
