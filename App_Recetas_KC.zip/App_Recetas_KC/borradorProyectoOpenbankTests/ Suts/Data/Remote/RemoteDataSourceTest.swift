//
//  RemoteDataSourceTest.swift
//  borradorProyectoOpenbankTests
//

import XCTest
@testable import borradorProyectoOpenbank

final class RemoteDataSourceTest: XCTestCase {
    
    var sut: RemoteDataSourceProtocol?
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        // Configuramos el mock de URLSession
        let configuration = URLSessionConfiguration.default
        configuration.protocolClasses = [URLProtocolMock.self]
        
        // Inyectamos la configuración nuestra al mock
        let mockURLSession = URLSession.init(configuration: configuration)
        sut = RemoteDataSourceImpl(session: mockURLSession)
    }
    
    override func tearDownWithError() throws {
        sut = nil
        try super.tearDownWithError()
    }
    
    func testRemoteDataSource_whenGetRecipesWithStatusCode400_completionReturnError() throws {
        // GIVEN
        let expectation = XCTestExpectation(description: "400 ERROR")
        
        // WHEN
        URLProtocolMock.requestHandler = { request in
            let response = HTTPURLResponse(url: request.url!, statusCode: 400, httpVersion: nil, headerFields: nil)!
            return (response, nil)
        }
        sut?.getRecipes(query: "", completion: { result, error in
            switch error {
            case .errorCode(let errorCode):
                XCTAssertEqual(errorCode, 400, "The error has to be 400")
                expectation.fulfill()
            default:
                XCTFail("This request must throw 400 error")
                expectation.fulfill()
            }
        })
        
        wait(for: [expectation], timeout: 1.0)
        
    }
    
    
    func testRemoteDataSource_whenGetRecipesWithStatusCode200_completionReturnResult() {
        
        let expectation = XCTestExpectation(description: "200")
        
        let stubResultElement = ResultElement(id: 1, title: "Stub Recipe", image: "stub_image.jpg", imageType: .jpg, readyInMinutes: 45,servings: 4)
        let stubResult = Result(results: [stubResultElement], offset: 0, number: 1, totalResults: 1)
        
        do {
            let resultData = try JSONEncoder().encode(stubResult)
            
            URLProtocolMock.requestHandler = { request in
                let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!
                return (response, resultData)
            }
            
            sut?.getRecipes(query: "") { result, error in
                XCTAssertNotNil(result, "Result should not be nil on success")
                XCTAssertNil(error, "Error should be nil on success")
                
                if let resultData = result?.results {
                    XCTAssertEqual(resultData.count, 1, "Expected 1 result")
                    XCTAssertEqual(resultData[0].title, "Stub Recipe", "Expected title should match")
                    // Add more assertions based on your mock data
                } else {
                    XCTFail("Result data should not be nil")
                }
                
                expectation.fulfill()
            }
            
            wait(for: [expectation], timeout: 1.0)
        } catch {
            XCTFail("Failed to encode stub result: \(error)")
        }
    }
    
}
