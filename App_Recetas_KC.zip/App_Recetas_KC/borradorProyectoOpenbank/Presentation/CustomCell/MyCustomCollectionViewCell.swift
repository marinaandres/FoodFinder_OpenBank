//
//  MyCustomCollectionViewCell.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 7/8/23.
//

import UIKit

class MyCustomCollectionViewCell: UICollectionViewCell {
    
    // MARK: - Outlets
    
    @IBOutlet weak var myCellImage: UIImageView!
    @IBOutlet weak var myCellLabel: UILabel!
    
    // MARK: - View lifecycle
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setImageLayout()
    }
    // MARK: - Methods
    
    func setImageLayout() {
        myCellImage.image = UIImage(named: "fondo2")
        myCellImage.layer.cornerRadius = myCellImage.frame.height / 8
        myCellImage.clipsToBounds = true
        myCellLabel.font = UIFont.boldSystemFont(ofSize: 18)
    }

}



