//
//  ListViewController.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 3/8/23.
//

import UIKit

class ListViewController: UIViewController {
    
    // MARK: - Initial Variables
    
    var listViewModel: ListViewModel?
    private let myCellWidth = UIScreen.main.bounds.width/2.3
    private let myCellHeight = UIScreen.main.bounds.width/1.9
    
    // MARK: - Outlets
    
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    // MARK: - View controller lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setViewModel()
        setCollectionView()
        setSearchBar()
        
    }
    // MARK: - Methods
    private func setViewModel() {
        let remoteDataSource = RemoteDataSourceImpl()
        let repository = RepositoryImpl(remoteDataSource: remoteDataSource)
        self.listViewModel = ListViewModel(repository: repository, listView: self)
    }
    
    private func setCollectionView() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UINib(nibName: "MyCustomCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "myCell")
    }
    private func setSearchBar() {
        searchBarOutlet.delegate = self
    }
    private func configureBackButton(){
        self.navigationController?.navigationBar.tintColor = UIColor.black
        let backButtonImage = UIImage(named: "back_24")
        navigationController?.navigationBar.backIndicatorImage = backButtonImage
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = backButtonImage
    }
}
    // MARK: - Extensions

extension ListViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        listViewModel?.getRecipe(withQuery: searchText) {
            
            DispatchQueue.main.async {
                self.collectionView.reloadData()
                
            }
        }
    }
}

extension ListViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listViewModel?.filteredRecipes.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        //creamos celda
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as? MyCustomCollectionViewCell
        
        //Comprobamos que el resultado sea correcto
        guard let result = listViewModel?.result else {
            return cell!
           }
        
        //Comprobamos que el indexpath.row sea positivo
        guard indexPath.row < result.results.count else {
            return cell!
           }
        
        //Asignamos el texto del resultado al titulo de la receta
        let recipe = result.results[indexPath.row]
        cell!.myCellLabel.text = recipe.title
        
        //Asignamos la imagen del resultado a la imagen de la receta
        let imageUrlString = recipe.image
        
        if let imageUrl = URL(string: imageUrlString) {
            cell!.myCellImage.setImage(url: imageUrl)
        } else {
            cell!.myCellImage.image = UIImage(named: "placeholderImage")
        }
        
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        return 10.0
    }
}

extension ListViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if let selectedRecipe = listViewModel?.filteredRecipes[indexPath.row] {
                   let detailViewModel = DetailViewModel(selectedRecipe: selectedRecipe)
                   let detailViewController = DetailViewController(viewModel: detailViewModel)
                   navigationController?.pushViewController(detailViewController, animated: true)
                   navigationController?.navigationBar.backItem?.leftBarButtonItem?.tintColor = .white
               }
    }
}
extension ListViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //Diseñamos el item del collectionView
        return CGSize(width: myCellWidth, height: myCellHeight)
    }
}


