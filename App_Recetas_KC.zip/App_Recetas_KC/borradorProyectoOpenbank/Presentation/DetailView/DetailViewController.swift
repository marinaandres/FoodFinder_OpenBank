//
//  DetailViewController.swift
//  borradorProyectoOpenbank
//
//  Created by Marina Andrés Aragón on 3/8/23.
//

import UIKit

class DetailViewController: UIViewController {
    
    // MARK: - Initial Variables
    
    var viewModel: DetailViewModel!
    
    // MARK: - Outlets
    
    @IBOutlet weak var recipeImage: UIImageView!
    @IBOutlet weak var recipeTitle: UITextView!
    @IBOutlet weak var recipeTime: UILabel!
    @IBOutlet weak var recipeServings: UILabel!
    
    // MARK: - Init
    
    init(viewModel: DetailViewModel) {
        super.init(nibName: nil, bundle: nil)
        self.viewModel = viewModel
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - View controller lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        
    }
    
    // MARK: - Methods
    
    func configureView() {
        configureTitle()
        configureImage()
        configureServingsAndTime()
        configureBackButton()
    }
    
    private func configureTitle() {
        recipeTitle.text = viewModel.recipeTitle
    }
    
    private func configureImage() {
        if let imageUrl = viewModel.recipeImageURL {
            recipeImage.setImage(url: imageUrl)
            viewModel.setImageBounds(for: recipeImage)
        } else if let image = viewModel.recipeImageUI {
            recipeImage.image = image
            viewModel.setImageBounds(for: recipeImage)
        }
    }
    
    private func configureServingsAndTime() {
        recipeServings.text = viewModel.recipeServings
        recipeTime.text = "\(viewModel.recipeTime!) min"
    }
    
    private func configureBackButton(){
        self.navigationController?.navigationBar.tintColor = UIColor.white
        let backButtonImage = UIImage(named: "back_24")
        navigationController?.navigationBar.backIndicatorImage = backButtonImage
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = backButtonImage
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}
